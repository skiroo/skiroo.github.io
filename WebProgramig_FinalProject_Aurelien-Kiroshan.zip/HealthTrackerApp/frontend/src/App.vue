<template>
    <div id="app">
        <h1>Please read the README!</h1>
    </div>
</template>
