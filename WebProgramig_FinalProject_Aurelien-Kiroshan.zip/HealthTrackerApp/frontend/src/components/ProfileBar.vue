<template>
    <div class="profile">
        <img src="../public/img/avatar.png" alt="User Avatar" />
        <h3>John</h3>
        <p>Gender: Male, Age: 21</p>
        <p>Height: 165 cm</p>
        <p>Weight: 62 kg</p>
        <p>Blood: O-</p>
    </div>
</template>
  
<script>
    export default {
        name: "ProfileBar",
    };
</script>
  
<style scoped>
/* Add your profile bar-specific styles here */
</style>
  