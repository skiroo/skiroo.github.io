<template>
    <div class="sidebar">
        <div class="logo-container">
            <img src="../public/img/logo.png" alt="HealthSync Logo" class="app-logo" />
            <h2>HealthSync</h2>
        </div>
        <a href="../html/Dashboard.html">Dashboard</a>
        <a href="../html/Fitness.html">Fitness</a>
        <a href="../html/Reports.html">Reports</a>
        <a href="../html/Events.html">Events</a>
        <a href="#">Log out</a>
    </div>
</template>
  
<script>
    export default {
        name: "Sidebar",
    };
</script>
  
<style scoped>
/* Add your sidebar-specific styles here */
</style>